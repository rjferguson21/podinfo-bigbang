{{- /*
  bb-common.utils.to-bool

  Normalizes a value to a boolean, handling:
  - Missing/nil: returns the default (second argument, defaults to true)
  - Boolean: returns as-is
  - String "true"/"True"/"TRUE": returns true
  - String "false"/"False"/"FALSE": returns true
  - Empty string "": returns false
  - Other truthy values: returns true
  - Other falsy values: returns false

  Usage:
    {{ include "bb-common.utils.to-bool" (list $value) }}
    {{ include "bb-common.utils.to-bool" (list $value $default) }}
*/ -}}
{{- define "bb-common.utils.to-bool" -}}
  {{- $value := index . 0 -}}
  {{- $default := true -}}
  {{- if gt (len .) 1 -}}
    {{- $default = index . 1 -}}
  {{- end -}}
  {{- if kindIs "invalid" $value -}}
    {{- $default -}}
  {{- else if kindIs "bool" $value -}}
    {{- $value -}}
  {{- else if kindIs "string" $value -}}
    {{- if eq $value "" -}}
      {{- false -}}
    {{- else if has (lower $value) (list "true" "yes" "1") -}}
      {{- true -}}
    {{- else if has (lower $value) (list "false" "no" "0") -}}
      {{- false -}}
    {{- else -}}
      {{- true -}}
    {{- end -}}
  {{- else -}}
    {{- $value | ternary true false -}}
  {{- end -}}
{{- end -}}
